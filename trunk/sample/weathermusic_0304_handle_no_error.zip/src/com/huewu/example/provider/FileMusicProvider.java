package com.huewu.example.provider;

import java.util.ArrayList;
import java.util.List;

import com.huewu.example.R;

import android.content.Context;

public class FileMusicProvider implements IMusicProvider{
	
	List<IMusicItem> list = null;
	Context context = null;

	public FileMusicProvider(Context context) {
		this.context = context;
	}

	@Override
	public List<IMusicItem> getMusicList(int type) {
		buildMusicList(type);
		return list;
	}
	
	private void buildMusicList(int type){
		list = new ArrayList<IMusicItem>();
		
		switch(type){
		case IWeatherProvider.WEATHER_SUNNY:
			list.add(new FileMusicItem(context.getString(R.string.sunny1)));
			list.add(new FileMusicItem(context.getString(R.string.sunny2)));
			list.add(new FileMusicItem(context.getString(R.string.cloudy1)));
			list.add(new FileMusicItem(context.getString(R.string.snow1)));
			break;
		case IWeatherProvider.WEATHER_CLODUY:
			list.add(new FileMusicItem(context.getString(R.string.cloudy1)));
			list.add(new FileMusicItem(context.getString(R.string.cloudy2)));
			list.add(new FileMusicItem(context.getString(R.string.rain1)));
			list.add(new FileMusicItem(context.getString(R.string.snow1)));
			break;
		case IWeatherProvider.WEATHER_RAIN:
			list.add(new FileMusicItem(context.getString(R.string.rain1)));
			list.add(new FileMusicItem(context.getString(R.string.rain2)));
			list.add(new FileMusicItem(context.getString(R.string.cloudy1)));
			list.add(new FileMusicItem(context.getString(R.string.snow1)));
			break;
		case IWeatherProvider.WEATHER_SNOW:
			list.add(new FileMusicItem(context.getString(R.string.snow1)));
			list.add(new FileMusicItem(context.getString(R.string.snow2)));
			list.add(new FileMusicItem(context.getString(R.string.cloudy1)));
			list.add(new FileMusicItem(context.getString(R.string.sunny1)));
			break;
		}
	}
}//end of class
