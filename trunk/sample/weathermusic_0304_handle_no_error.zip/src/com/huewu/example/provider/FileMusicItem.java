package com.huewu.example.provider;

import java.io.File;

import android.net.Uri;

public class FileMusicItem implements IMusicItem{
	
	private String title = "";
	private Uri uri = null;
	
	public FileMusicItem(String string){
		File file = new File(string);
		
		if(file.exists() == true){
			title = file.getName();
			String uriStr = "file://"+ file.getAbsolutePath();
			uri = Uri.parse(uriStr);		
		}
	}

	@Override
	public String getTtitle() {
		return title;
	}

	@Override
	public Uri getUri() {
		return uri;
	}

	@Override
	public boolean isLocal() {
		return true;
	}
}//end of class
