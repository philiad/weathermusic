package com.huewu.example.provider;

import java.util.List;

public interface IMusicProvider {

	List<IMusicItem> getMusicList(int type);
}
