package com.huewu.example;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import com.huewu.example.adapter.MusicItemAdapter;
import com.huewu.example.provider.FileMusicProvider;
import com.huewu.example.provider.IMusicItem;
import com.huewu.example.provider.RandomWeatherProvider;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class WeatherMusic extends Activity {

    private static final String TAG = "WeatherMusic";
    
	private TextView textView = null;
	private ImageView weatherIcon = null;
	private TextView musicTextView = null;
	private ListView listView = null;
	
	private RadioStation station = null;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		station = new RadioStation(this, new RandomWeatherProvider(this), new FileMusicProvider(this));
		textView = (TextView) findViewById(R.id.weather_desc);
		musicTextView = (TextView) findViewById(R.id.music_status);
		weatherIcon = (ImageView) findViewById(R.id.weather_icon);
		listView = (ListView)findViewById(R.id.music_list);
		listView.setOnItemClickListener(new OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				station.handlePlayorStopMusic(arg2);
				updateMusicStatus();
			}
		});
	}

	@Override
	protected void onResume() {
		super.onResume();
		String desc = station.getWeatherDescription();
		textView.setText(desc);
		weatherIcon.setImageDrawable(station.getWeatherDrawable());
		
		IMusicItem[] musics = new IMusicItem[station.getMusicList().size()];
		musics = station.getMusicList().toArray(musics);
		
		MusicItemAdapter adapter 
			= new MusicItemAdapter(this, R.layout.list_item, musics);
		
		listView.setAdapter(adapter);
		updateMusicStatus();
		
		HttpClient client = new DefaultHttpClient();
		HttpPost post = new HttpPost();
		
	}
	
	@Override
	protected void onStop() {
		super.onStop();
		station.stopMusic();
	}
	
	private void updateMusicStatus(){
		if( station.isPlaying() == true )
			musicTextView.setText(R.string.playing);
		else
			musicTextView.setText(R.string.stopped);
	}
}//end of class
